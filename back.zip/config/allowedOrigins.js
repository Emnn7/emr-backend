const allowedOrigins = [
    'http://localhost:3000',
    "http://localhost:5000",
  ];
  
  module.exports = allowedOrigins;
  